import Foundation

var inrBalanace = 2500.14
var usdBalanace = 855.00
var eurBalance = 345.00
var currflag = 0
