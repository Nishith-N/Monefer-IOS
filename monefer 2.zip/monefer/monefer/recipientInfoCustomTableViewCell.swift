//
//  recipientInfoCustomTableViewCell.swift
//  monefer
//
//  Created by Anilkumar on 28/06/22.
//

import UIKit

class recipientInfoCustomTableViewCell: UITableViewCell {
    
    let screenSize = UIScreen.main.bounds.size
    lazy var backView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: 100))
        
        return view
    }()
    
    lazy var HeaderLabel: UILabel! = {
        let account = UILabel(frame: CGRect(x: 20, y: 25, width: (screenSize.width*3/4)-(screenSize.width*1/4), height: 30))
        account.textColor = UIColor.black
        account.font = .boldSystemFont(ofSize: 20)
     
        return account
    }()
    
    lazy var SubLabel: UILabel = {
        let msge = UILabel(frame: CGRect(x: 20, y: 55, width: (screenSize.width*3/4)-(screenSize.width*1/4)+20, height: 30))
        msge.textColor = UIColor.black
        msge.font = msge.font.withSize(14.0)
        msge.numberOfLines = 2
        
        return msge
    }()
    
    lazy var EditBtn: UIButton = {
        let time = UIButton(frame: CGRect(x: (screenSize.width*3/4)+10, y:25, width: screenSize.width-(screenSize.width*3/4), height: 30))
        time.setTitle("Edit", for: .normal)
        time.setTitleColor(UIColor.red, for: .normal)
        
        
       
        return time
    }()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(backView)
        backView.addSubview(HeaderLabel)
        backView.addSubview(SubLabel)
        backView.addSubview(EditBtn)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
