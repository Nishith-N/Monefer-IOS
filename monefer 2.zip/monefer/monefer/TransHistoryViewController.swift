//
//  TransHistoryViewController.swift
//  monefer
//
//  Created by Anilkumar on 28/06/22.
//

import UIKit

class translist {
    var profIcon: String?
    var contactName: String?
    var messageLbl: String?
    var sendLbl: String?
    var currency: String?

    init(initprof:String, initcont:String, initmsg:String, inittime:String, initnicon:String) {
        self.profIcon = initprof
        self.contactName = initcont
        self.messageLbl = initmsg
        self.sendLbl = inittime
        self.currency = initnicon
    }
}


class TransHistoryViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UITableViewDelegate,UITableViewDataSource {
 
    var itemArray = [translist]()
    
    
    @IBOutlet weak var homeBtn: UIButton!
    
    @IBOutlet weak var transHistTableView: UITableView!
    
    @IBOutlet weak var searchBtn: UIButton!
    @IBOutlet weak var balanceCollectionViewLayout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var balancesCollectionView: UICollectionView!
    
    @IBOutlet weak var headerBackgroundView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tableviewcell1 = translist(initprof: "prof-1", initcont: "Surja Sen Das Raj", initmsg: "Payment Recieved", inittime: "+333 EUR", initnicon: "Mar 10, 2022")
        itemArray.append(tableviewcell1)
        let tableviewcell2 = translist(initprof: "prof-2", initcont: "Reece", initmsg: "Payment Sent", inittime: "-70 USD", initnicon: "Mar 2,2022")
        itemArray.append(tableviewcell2)
        let tableviewcell3 = translist(initprof: "prof-3", initcont: "Trent", initmsg: "Payment Sent", inittime: "-40 INR", initnicon: "April 2,2022")
        itemArray.append(tableviewcell3)
        
        transHistTableView.register(TransHistCustomTableViewCell.self, forCellReuseIdentifier: "Cell")
        
        headerBackgroundView.layer.cornerRadius = 30.0
        headerBackgroundView.clipsToBounds = true
        
        balancesCollectionView.delegate = self
        balancesCollectionView.dataSource = self
        
        self.homeBtn.addTarget(self, action: #selector(homeBtnAction(sender:)), for: .touchUpInside)
        
        transHistTableView.delegate = self
        transHistTableView.dataSource = self
        
        homeBtn.layer.cornerRadius = 15.0
        homeBtn.clipsToBounds = true
        
    
        balanceCollectionViewLayout.minimumLineSpacing = 15
        balanceCollectionViewLayout.minimumInteritemSpacing = 15
        

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    
    @objc func homeBtnAction(sender:UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "aboutViewController") as! aboutViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "balancesCustomCollectionViewCell", for: indexPath) as! balancesCustomCollectionViewCell
        
        cell.widthAnchor.constraint(equalToConstant: 200).isActive = true
        cell.heightAnchor.constraint(equalToConstant: balancesCollectionView.frame.height-20).isActive = true
        
   
        
        cell.backView.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 0).isActive = true
        cell.backView.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 10).isActive = true
        cell.backView.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: 0).isActive = true
        cell.backView.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: 0).isActive = true
        cell.backView.translatesAutoresizingMaskIntoConstraints = false
        
        
        cell.currencyIcon.widthAnchor.constraint(equalToConstant: 50).isActive = true
        cell.currencyIcon.heightAnchor.constraint(equalToConstant: 50).isActive = true
        cell.currencyIcon.topAnchor.constraint(equalTo: cell.backView.topAnchor, constant: 5).isActive = true
        cell.currencyIcon.leadingAnchor.constraint(equalTo: cell.backView.leadingAnchor, constant: 10).isActive = true
        cell.currencyIcon.translatesAutoresizingMaskIntoConstraints = false
        
        cell.layer.cornerRadius = 20.0
        cell.clipsToBounds = true
        
        if indexPath.item == 0
        {
            cell.amountLabel.text = "\(eurBalance)"
            cell.currencyIcon.image = UIImage(named: "eurosymbol")
            cell.currencyLabel.text = "EUR"
        }
        if indexPath.item == 1
        {
            cell.amountLabel.text = "\(usdBalanace)"
            cell.currencyIcon.image = UIImage(named: "usdsymbol")
            cell.currencyLabel.text = "USD"
        }
        if indexPath.item == 2
        {
            cell.amountLabel.text = "\(inrBalanace)"
            cell.currencyIcon.image = UIImage(named: "inrsymbol")
            cell.currencyLabel.text = "INR"
        }
        
        
        
        
        return cell
    }

    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                TransHistCustomTableViewCell else {fatalError("Unable to run")}
        
        cell.profimage.image = UIImage(named: itemArray[indexPath.row].profIcon!)
          cell.contacts.text = itemArray[indexPath.row].contactName
          cell.msge.text = itemArray[indexPath.row].messageLbl
         cell.sendLbl.text = itemArray[indexPath.row].sendLbl
          cell.notifilbl.text = itemArray[indexPath.row].currency
        
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

}
