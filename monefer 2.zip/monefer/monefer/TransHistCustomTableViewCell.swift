//
//  TransHistCustomTableViewCell.swift
//  monefer
//
//  Created by Anilkumar on 29/06/22.
//

import UIKit

class TransHistCustomTableViewCell: UITableViewCell {
    
    let screenSize = UIScreen.main.bounds.size
    lazy var backView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: screenSize.width, height: 100))
        
        return view
    }()
    lazy var profimage: UIImageView = {
       let pimage = UIImageView(/*frame: CGRect(x: 15, y: 10, width: 50, height: 50)*/)
        pimage.image = UIImage(named: "prof-1")
        pimage.translatesAutoresizingMaskIntoConstraints = false
        pimage.contentMode = .scaleAspectFit
      
        pimage.layer.cornerRadius = 25
        pimage.clipsToBounds = true
        return pimage
    }()

    lazy var contacts: UILabel! = {
        let contact = UILabel(frame: CGRect(x: screenSize.width*1/4-10, y: 25, width: (screenSize.width*3/4)-(screenSize.width*1/4), height: 30))
        contact.textColor = UIColor.black
     
        return contact
    }()
    
    lazy var msge: UILabel = {
        let msge = UILabel(frame: CGRect(x: screenSize.width*1/4-10, y: 55, width: (screenSize.width*3/4)-(screenSize.width*1/4), height: 30))
        msge.textColor = UIColor.lightGray
        msge.font = msge.font.withSize(14.0)
        
        return msge
    }()

    lazy var sendLbl: UILabel = {
        let time = UILabel(frame: CGRect(x: (screenSize.width*3/4)+10, y:25, width: screenSize.width-(screenSize.width*3/4), height: 30))
        time.textColor = UIColor.black
        time.font = .boldSystemFont(ofSize: 14)
    
        time.textAlignment = .center
       
        return time
    }()
    
    lazy var notifilbl: UILabel = {
        let notifica = UILabel()
        notifica.textColor = UIColor.lightGray
        notifica.font = notifica.font.withSize(12)
        notifica.translatesAutoresizingMaskIntoConstraints = false
        notifica.textAlignment = .center
       
        return notifica
    }()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(backView)
        backView.addSubview(profimage)
        backView.addSubview(contacts)
        backView.addSubview(msge)
        backView.addSubview(sendLbl)
        backView.addSubview(notifilbl)
        profimage.leadingAnchor.constraint(equalTo: self.backView.leadingAnchor, constant: 25).isActive = true
        profimage.widthAnchor.constraint(equalToConstant: 50).isActive = true
        profimage.heightAnchor.constraint(equalToConstant: 50).isActive = true
        profimage.topAnchor.constraint(equalTo: self.backView.topAnchor, constant: 25).isActive = true
        
        notifilbl.leadingAnchor.constraint(equalTo: self.msge.trailingAnchor, constant: 10).isActive = true
        notifilbl.widthAnchor.constraint(equalToConstant: 100).isActive = true
        notifilbl.heightAnchor.constraint(equalToConstant: 20).isActive = true
        notifilbl.topAnchor.constraint(equalTo: self.sendLbl.bottomAnchor, constant: 10).isActive = true
        
        sendLbl.leadingAnchor.constraint(equalTo: self.msge.trailingAnchor, constant: 10).isActive = true
        sendLbl.widthAnchor.constraint(equalToConstant: 100).isActive = true
        sendLbl.heightAnchor.constraint(equalToConstant: 20).isActive = true
        sendLbl.topAnchor.constraint(equalTo: backView.topAnchor, constant: 30).isActive = true
        sendLbl.translatesAutoresizingMaskIntoConstraints = false
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
