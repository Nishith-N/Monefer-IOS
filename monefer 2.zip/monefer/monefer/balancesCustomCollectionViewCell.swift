//
//  balancesCustomCollectionViewCell.swift
//  monefer
//
//  Created by Anilkumar on 28/06/22.
//

import UIKit

class balancesCustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var currencyIcon:UIImageView!
    @IBOutlet weak var amountLabel:UILabel!
    @IBOutlet weak var currencyLabel:UILabel!
    @IBOutlet weak var backView:UIView!
    
}
