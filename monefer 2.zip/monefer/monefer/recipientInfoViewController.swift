//
//  recipientInfoViewController.swift
//  monefer
//
//  Created by Anilkumar on 28/06/22.
//

import UIKit

class recipientInfoViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    
  
    @IBOutlet weak var amountTextField: UITextField!
    
    @IBOutlet weak var sendBtn: UIButton!
    
    @IBOutlet weak var recipientInfoTableView: UITableView!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var SenderTypeLabel: UILabel!
    @IBOutlet weak var headerNameLabel: UILabel!
   
    var recieverName = ""
    var recieverBank = ""
    var recieverSend = ""
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        backgroundView.layer.cornerRadius = 30.0
        backgroundView.clipsToBounds = true
        
        amountTextField.delegate = self
        amountTextField.layer.cornerRadius = 8.0
        amountTextField.clipsToBounds = true
        amountTextField.keyboardType = .numberPad
        amountTextField.layer.borderWidth = 1.0
        amountTextField.layer.borderColor = UIColor.black.cgColor
        amountTextField.setLeftPaddingPoints(10)
        
        
        self.addDoneButtonOnKeyboard()
        
        sendBtn.backgroundColor = .black
        sendBtn.layer.cornerRadius = sendBtn.frame.width/2
        sendBtn.clipsToBounds = true
        
        recipientInfoTableView.delegate = self
        recipientInfoTableView.dataSource = self
        
        SenderTypeLabel.text = "Your " + recieverSend + " Account"
        headerNameLabel.text = recieverBank
        
        self.sendBtn.addTarget(self, action: #selector(SenderBtnAction(sender:)), for: .touchUpInside)
        
        recipientInfoTableView.register(recipientInfoCustomTableViewCell.self, forCellReuseIdentifier: "Cell")
        
        
      
        // Do any additional setup after loading the view.
    }
    
    func addDoneButtonOnKeyboard(){
            let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
            doneToolbar.barStyle = .default

            let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))

            let items = [flexSpace, done]
            doneToolbar.items = items
            doneToolbar.sizeToFit()

            amountTextField.inputAccessoryView = doneToolbar
        }
    
    @objc func doneButtonAction(){
            amountTextField.resignFirstResponder()
        }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == amountTextField
        {
            textField.becomeFirstResponder()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == amountTextField
        {
            textField.resignFirstResponder()
        }
    }
    
    @objc func SenderBtnAction(sender: UIButton)
    {
        
        if (amountTextField.text != "")
        {
            if(recieverSend == "INR")
            {
                inrBalanace -= Double(amountTextField.text!)!
            }
            else if(recieverSend == "USD")
            {
                usdBalanace -= Double(amountTextField.text!)!
            }
            else if(recieverSend == "EUR")
            {
                eurBalance -= Double(amountTextField.text!)!
            }
        let vc = storyboard?.instantiateViewController(withIdentifier: "TransHistoryViewController") as! TransHistoryViewController
        self.navigationController?.pushViewController(vc, animated: true)
        }
        else
        {
            let alertController = UIAlertController(title: "Error", message:
                    "Enter an amount", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default))

                self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                recipientInfoCustomTableViewCell else {fatalError("Unable to run")}
        
        
        
        if indexPath.row == 0
        {
            cell.HeaderLabel.text = "Account Holder"
            cell.SubLabel.text = recieverName
            cell.EditBtn.isHidden = true
        }
        
        if indexPath.row == 1
        {
            cell.HeaderLabel.text = "Nick Name"
            cell.SubLabel.text = "My " + recieverBank + " Account"
            cell.EditBtn.isHidden = false

        }
        
        if indexPath.row == 2
        {
            cell.HeaderLabel.text = "Email Address"
            cell.EditBtn.isHidden = true
            cell.SubLabel.text = recieverName.lowercased().replacingOccurrences(of: " ", with: "") + "@gmail.com"
        }
        
        if indexPath.row == 3
        {
            cell.HeaderLabel.text = "Branch Code"
            cell.SubLabel.text = "\(Int.random(in: 1000000...999999999))"
            cell.EditBtn.isHidden = true
            
        }
        if indexPath.row == 4
        {
            cell.HeaderLabel.text = "Bank Code"
            cell.SubLabel.text = "\(Int.random(in: 10...999))"
            cell.EditBtn.isHidden = true
            
        }
        if indexPath.row == 5
        {
            cell.HeaderLabel.text = "Account Number"
            cell.SubLabel.text = "\(Int.random(in: 100000000...9999999999))"
            cell.EditBtn.isHidden = true
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    

    

}

extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
}
