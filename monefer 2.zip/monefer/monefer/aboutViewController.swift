//
//  aboutViewController.swift
//  monefer
//
//  Created by Anilkumar on 24/06/22.
//

import UIKit

class aboutViewController: UIViewController {

    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var headerImage: UIImageView!
    @IBOutlet weak var headerLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        headerLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 25).isActive = true
        headerLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        headerLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        headerLabel.heightAnchor.constraint(equalToConstant: UIScreen.main.bounds.size.height/2-50).isActive = true
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        
        headerLabel.text = "Easy &\nLow cost\ntransfer"
        
        headerImage.topAnchor.constraint(equalTo: nextBtn.bottomAnchor, constant: 0).isActive = true
        headerImage.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        headerImage.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        headerImage.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        headerImage.translatesAutoresizingMaskIntoConstraints = false
        
        
        nextBtn.heightAnchor.constraint(equalToConstant: 30).isActive = true
        nextBtn.topAnchor.constraint(equalTo: headerLabel.bottomAnchor, constant: 0).isActive = true
        nextBtn.widthAnchor.constraint(equalToConstant: 150).isActive = true
        nextBtn.translatesAutoresizingMaskIntoConstraints = false
        
        self.nextBtn.addTarget(self, action: #selector(nextBtnAction(sender:)), for: .touchUpInside)
        
        
     

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    @objc func nextBtnAction(sender:UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "recipientsPageViewController") as! recipientsPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
