import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var goButton: UIButton!
    @IBOutlet weak var headerLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        headerLabel.text = "Safe\nway to\ntransfer\nmoney"
        headerLabel.textColor = .orange
        goButton.layer.cornerRadius = goButton.frame.size.width/2
        goButton.clipsToBounds = true
        goButton.backgroundColor = .black
        self.goButton.addTarget(self, action: #selector(goButtonAction(sender:)), for: .touchUpInside)
        setGradientBackground()
        
        
        
        // Do any additional setup after loading the view.
    }
    
    @objc func goButtonAction(sender: UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func setGradientBackground() {
        let colorTop = UIColor(red: 253.0/255.0, green: 164.0/255.0, blue: 40.0/255.0, alpha: 1.0).cgColor
        let colormiddle =  UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        
                    
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [colorTop,colormiddle]
        gradientLayer.locations = [0.0, 0.5]
        gradientLayer.frame = self.view.bounds
                
        self.view.layer.insertSublayer(gradientLayer, at:0)
    }
}

