//
//  convertPageViewController.swift
//  monefer
//
//  Created by Anilkumar on 29/06/22.
//

import UIKit

class convertPageViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var balanceLabel: UILabel!
    @IBOutlet weak var bottomMoneyLabel: UILabel!
    @IBOutlet weak var buttonBackView: UIView!
    @IBOutlet weak var bottomConvertLabel: UILabel!

    @IBOutlet weak var topMoneyLabel: UITextField!
    @IBOutlet weak var topConvertLabel: UILabel!
    @IBOutlet weak var bottomCurrencyLabel: UILabel!
    @IBOutlet weak var bottomCurrencyImage: UIImageView!
    @IBOutlet weak var currencyBottomImageView: UIView!
    @IBOutlet weak var currencyBottomBackView: UIView!
    @IBOutlet weak var currencyImageBackView: UIView!
    @IBOutlet weak var topCurrencyLabel: UILabel!
    @IBOutlet weak var topCurrencyImage: UIImageView!
    @IBOutlet weak var currencyTopBackView: UIView!
    @IBOutlet weak var rateNumber: UILabel!
    @IBOutlet weak var amountNumber: UILabel!
    @IBOutlet weak var feeNumber: UILabel!
    @IBOutlet weak var rateLabel: UILabel!
    @IBOutlet weak var amountConvertLabel: UILabel!
    @IBOutlet weak var ourFeeLabel: UILabel!
    @IBOutlet weak var convertedView: UIView!
    @IBOutlet weak var amountToConvertView: UIView!
    @IBOutlet weak var backView: UIView!

    @IBOutlet weak var continueBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        backView.topAnchor.constraint(equalTo: view.topAnchor, constant: (view.frame.height/2)-80).isActive = true
        backView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50).isActive = true
        backView.widthAnchor.constraint(equalToConstant: 30).isActive = true
        backView.heightAnchor.constraint(equalToConstant: 200).isActive = true
        backView.translatesAutoresizingMaskIntoConstraints = false
        
        
//        let gradient = CAGradientLayer()
//        gradient.frame =  CGRect(origin: .zero, size: backView.frame.size)
//        gradient.colors = [UIColor.blue.cgColor, UIColor.green.cgColor]
//        let shape = CAShapeLayer()
//        shape.lineWidth = 2
//        shape.path = UIBezierPath(rect: backView.bounds).cgPath
//        shape.strokeColor = UIColor.black.cgColor
//        shape.fillColor = UIColor.clear.cgColor
//        gradient.mask = shape
//        backView.layer.addSublayer(gradient)
        
        ourFeeLabel.topAnchor.constraint(equalTo: amountToConvertView.bottomAnchor, constant: 10).isActive = true
        ourFeeLabel.leadingAnchor.constraint(equalTo: backView.leadingAnchor, constant: 20).isActive = true
        ourFeeLabel.widthAnchor.constraint(equalToConstant: 150).isActive = true
        ourFeeLabel.text = "- Our Fee"
        ourFeeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        amountConvertLabel.topAnchor.constraint(equalTo: ourFeeLabel.bottomAnchor, constant: 10).isActive = true
        amountConvertLabel.leadingAnchor.constraint(equalTo: backView.leadingAnchor, constant: 20).isActive = true
        amountConvertLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
        amountConvertLabel.translatesAutoresizingMaskIntoConstraints = false
        amountConvertLabel.text = "- Amount we'll convert"
        
        rateLabel.topAnchor.constraint(equalTo: amountConvertLabel.bottomAnchor, constant: 10).isActive = true
        rateLabel.leadingAnchor.constraint(equalTo: backView.leadingAnchor, constant: 20).isActive = true
        rateLabel.widthAnchor.constraint(equalToConstant: 150).isActive = true
        rateLabel.translatesAutoresizingMaskIntoConstraints = false
        rateLabel.text = "- Rate"
        
        feeNumber.topAnchor.constraint(equalTo: amountToConvertView.bottomAnchor, constant: 10).isActive = true
        feeNumber.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50).isActive = true
        feeNumber.widthAnchor.constraint(equalToConstant: 100).isActive = true
        feeNumber.translatesAutoresizingMaskIntoConstraints = false
        feeNumber.text = "1.14 EUR"
        feeNumber.textAlignment = .right
        
        amountNumber.topAnchor.constraint(equalTo: feeNumber.bottomAnchor, constant: 10).isActive = true
        amountNumber.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50).isActive = true
        amountNumber.widthAnchor.constraint(equalToConstant: 100).isActive = true
        amountNumber.translatesAutoresizingMaskIntoConstraints = false
        amountNumber.text = "214.86 EUR"
        amountNumber.textAlignment = .right
        
        rateNumber.topAnchor.constraint(equalTo: amountNumber.bottomAnchor, constant: 10).isActive = true
        rateNumber.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50).isActive = true
        rateNumber.widthAnchor.constraint(equalToConstant: 100).isActive = true
        rateNumber.translatesAutoresizingMaskIntoConstraints = false
        rateNumber.text = "0.8987867"
        rateNumber.textAlignment = .right
        
        self.continueBtn.addTarget(self, action: #selector(continueBtnAction(sender:)), for: .touchUpInside)
        
//        backView.layer.borderColor = UIColor.blue.cgColor
//        backView.layer.borderWidth = 4.0
        addTopBottomLeftBorders()
        
        
        amountToConvertView.bottomAnchor.constraint(equalTo: backView.topAnchor, constant: 50).isActive = true
        amountToConvertView.leadingAnchor.constraint(equalTo: backView.leadingAnchor, constant: 20).isActive = true
        amountToConvertView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50).isActive = true
        amountToConvertView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        amountToConvertView.translatesAutoresizingMaskIntoConstraints = false
        amountToConvertView.layer.cornerRadius = 15.0
        amountToConvertView.layer.borderColor = UIColor.lightGray.cgColor
        amountToConvertView.layer.borderWidth = 1.0
        
        
        convertedView.topAnchor.constraint(equalTo: backView.bottomAnchor, constant: -50).isActive = true
        convertedView.leadingAnchor.constraint(equalTo: backView.leadingAnchor, constant: 20).isActive = true
        convertedView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        convertedView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50).isActive = true
        convertedView.translatesAutoresizingMaskIntoConstraints = false
        convertedView.layer.cornerRadius = 15.0
        convertedView.layer.borderColor = UIColor.lightGray.cgColor
        convertedView.layer.borderWidth = 1.0
        
        
        currencyTopBackView.leadingAnchor.constraint(equalTo: amountToConvertView.leadingAnchor, constant: 0).isActive = true
        currencyTopBackView.bottomAnchor.constraint(equalTo: amountToConvertView.bottomAnchor, constant: 0).isActive = true
        currencyTopBackView.topAnchor.constraint(equalTo: amountToConvertView.topAnchor, constant: 0).isActive = true
        currencyTopBackView.widthAnchor.constraint(equalToConstant: (amountToConvertView.frame.width/4)+30).isActive = true
        currencyTopBackView.translatesAutoresizingMaskIntoConstraints = false
        
        currencyImageBackView.topAnchor.constraint(equalTo: currencyTopBackView.topAnchor, constant: 10).isActive = true
        currencyImageBackView.leadingAnchor.constraint(equalTo: currencyTopBackView.leadingAnchor, constant: (currencyTopBackView.frame.width/2)-30).isActive = true
        currencyImageBackView.widthAnchor.constraint(equalToConstant: 50).isActive = true
        currencyImageBackView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        currencyImageBackView.translatesAutoresizingMaskIntoConstraints = false
        currencyImageBackView.layer.cornerRadius = 25.0
        currencyImageBackView.clipsToBounds = true
        
        
        
        topCurrencyImage.leadingAnchor.constraint(equalTo: currencyImageBackView.leadingAnchor, constant: 10).isActive = true
        topCurrencyImage.trailingAnchor.constraint(equalTo: currencyImageBackView.trailingAnchor, constant: -10).isActive = true
        topCurrencyImage.bottomAnchor.constraint(equalTo: currencyImageBackView.bottomAnchor, constant: -10).isActive = true
        topCurrencyImage.topAnchor.constraint(equalTo: currencyImageBackView.topAnchor, constant: 10).isActive = true
        topCurrencyImage.translatesAutoresizingMaskIntoConstraints = false
        
        
        topCurrencyLabel.topAnchor.constraint(equalTo: currencyImageBackView.bottomAnchor, constant: 10).isActive = true
        topCurrencyLabel.leadingAnchor.constraint(equalTo: currencyTopBackView.leadingAnchor, constant: 10).isActive = true
        topCurrencyLabel.trailingAnchor.constraint(equalTo: currencyTopBackView.trailingAnchor, constant: -10).isActive = true
        topCurrencyLabel.translatesAutoresizingMaskIntoConstraints = false
        
        topCurrencyLabel.text = "EUR"
        topCurrencyLabel.font = .boldSystemFont(ofSize: 17)
        
        topConvertLabel.topAnchor.constraint(equalTo: amountToConvertView.topAnchor, constant: 20).isActive = true
        topConvertLabel.leadingAnchor.constraint(equalTo: currencyTopBackView.trailingAnchor, constant: 20).isActive = true
        topConvertLabel.trailingAnchor.constraint(equalTo: amountToConvertView.trailingAnchor, constant: -10).isActive = true
        topConvertLabel.translatesAutoresizingMaskIntoConstraints = false
        topConvertLabel.text = "Convert"
        topConvertLabel.textColor = .lightGray
        
        topMoneyLabel.topAnchor.constraint(equalTo: topConvertLabel.bottomAnchor, constant: 10).isActive = true
        topMoneyLabel.leadingAnchor.constraint(equalTo: currencyTopBackView.trailingAnchor, constant: 20).isActive = true
        topMoneyLabel.trailingAnchor.constraint(equalTo: amountToConvertView.trailingAnchor, constant: -10).isActive = true
        topMoneyLabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
        topMoneyLabel.translatesAutoresizingMaskIntoConstraints = false
        topMoneyLabel.keyboardType = .numberPad
        
        balanceLabel.text = "You have " + "\(eurBalance)" + " in your balance"
        
        
        
        
        currencyBottomBackView.leadingAnchor.constraint(equalTo: convertedView.leadingAnchor, constant: 0).isActive = true
        currencyBottomBackView.bottomAnchor.constraint(equalTo: convertedView.bottomAnchor, constant: 0).isActive = true
        currencyBottomBackView.topAnchor.constraint(equalTo: convertedView.topAnchor, constant: 0).isActive = true
        currencyBottomBackView.widthAnchor.constraint(equalToConstant: (convertedView.frame.width/4)+30).isActive = true
        currencyBottomBackView.translatesAutoresizingMaskIntoConstraints = false
        
        currencyBottomImageView.topAnchor.constraint(equalTo: currencyBottomBackView.topAnchor, constant: 10).isActive = true
        currencyBottomImageView.leadingAnchor.constraint(equalTo: currencyBottomBackView.leadingAnchor, constant: (currencyBottomBackView.frame.width/2)-30).isActive = true
        currencyBottomImageView.widthAnchor.constraint(equalToConstant: 50).isActive = true
        currencyBottomImageView.heightAnchor.constraint(equalToConstant: 50).isActive = true
        currencyBottomImageView.translatesAutoresizingMaskIntoConstraints = false
        currencyBottomImageView.layer.cornerRadius = 25.0
        currencyBottomImageView.clipsToBounds = true
        
        
        bottomCurrencyImage.leadingAnchor.constraint(equalTo: currencyBottomImageView.leadingAnchor, constant: 10).isActive = true
        bottomCurrencyImage.trailingAnchor.constraint(equalTo: currencyBottomImageView.trailingAnchor, constant: -10).isActive = true
        bottomCurrencyImage.bottomAnchor.constraint(equalTo: currencyBottomImageView.bottomAnchor, constant: -10).isActive = true
        bottomCurrencyImage.topAnchor.constraint(equalTo: currencyBottomImageView.topAnchor, constant: 10).isActive = true
        bottomCurrencyImage.translatesAutoresizingMaskIntoConstraints = false
        
        
        bottomCurrencyLabel.topAnchor.constraint(equalTo: currencyBottomImageView.bottomAnchor, constant: 10).isActive = true
        bottomCurrencyLabel.leadingAnchor.constraint(equalTo: currencyBottomBackView.leadingAnchor, constant: 10).isActive = true
        bottomCurrencyLabel.trailingAnchor.constraint(equalTo: currencyBottomBackView.trailingAnchor, constant: -10).isActive = true
        bottomCurrencyLabel.translatesAutoresizingMaskIntoConstraints = false
        
        bottomCurrencyLabel.text = "INR"
        bottomCurrencyLabel.font = .boldSystemFont(ofSize: 17)
        
        bottomConvertLabel.topAnchor.constraint(equalTo: convertedView.topAnchor, constant: 20).isActive = true
        bottomConvertLabel.leadingAnchor.constraint(equalTo: currencyBottomBackView.trailingAnchor, constant: 20).isActive = true
        bottomConvertLabel.trailingAnchor.constraint(equalTo: convertedView.trailingAnchor, constant: -10).isActive = true
        bottomConvertLabel.translatesAutoresizingMaskIntoConstraints = false
        bottomConvertLabel.text = "To"
        bottomConvertLabel.textColor = .lightGray
        
        self.addDoneButtonOnKeyboard()
        
        bottomMoneyLabel.topAnchor.constraint(equalTo: bottomConvertLabel.bottomAnchor, constant: 10).isActive = true
        bottomMoneyLabel.leadingAnchor.constraint(equalTo: currencyBottomBackView.trailingAnchor, constant: 20).isActive = true
        bottomMoneyLabel.trailingAnchor.constraint(equalTo: convertedView.trailingAnchor, constant: -10).isActive = true
        bottomMoneyLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
        bottomMoneyLabel.translatesAutoresizingMaskIntoConstraints = false
                
        buttonBackView.layer.shadowColor = UIColor.lightGray.cgColor
        buttonBackView.layer.shadowOpacity = 10
        buttonBackView.layer.shadowOffset = CGSize.zero
        buttonBackView.layer.shadowRadius = 10
        buttonBackView.layer.cornerRadius = 10.0
   
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == topMoneyLabel
        {
            textField.becomeFirstResponder()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == topMoneyLabel
        {
            textField.resignFirstResponder()
        }
    }
    
    func addDoneButtonOnKeyboard(){
            let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
            doneToolbar.barStyle = .default

            let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))

            let items = [flexSpace, done]
            doneToolbar.items = items
            doneToolbar.sizeToFit()

            topMoneyLabel.inputAccessoryView = doneToolbar
        }
    
    @objc func doneButtonAction(){
            topMoneyLabel.resignFirstResponder()
        let value = Double(topMoneyLabel.text ?? "0")
        if (((value) ?? 0) < 0)
        {
            bottomMoneyLabel.text = "0"
        }
        else
        {
            bottomMoneyLabel.text = "\((value ?? 0)*82.67)"
        }
        }
    
    @objc func continueBtnAction(sender: UIButton)
    {
        if topMoneyLabel.text == ""
        {
            let alertController = UIAlertController(title: "Error", message:
                    "Enter an amount or Click Back", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default))

                self.present(alertController, animated: true, completion: nil)
        }
        else
        {
           inrBalanace += Double(bottomMoneyLabel.text!)!
            eurBalance -= Double(topMoneyLabel.text!)!
            let vc = storyboard?.instantiateViewController(withIdentifier: "TransHistoryViewController") as! TransHistoryViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
    }
    
    
    
    func addTopBottomLeftBorders() {
       let thickness: CGFloat = 1.0
       let topBorder = CALayer()
       let bottomBorder = CALayer()
        let leftBorder = CALayer()
       topBorder.frame = CGRect(x: 0.0, y: 0.0, width: self.backView.frame.size.width, height: thickness)
        bottomBorder.frame = CGRect(x:0.0, y: 198, width: self.backView.frame.size.width, height:thickness)
        leftBorder.frame = CGRect(x: 0.0, y: 0.0, width: thickness, height: 200)
       leftBorder.backgroundColor = UIColor.blue.cgColor
       topBorder.backgroundColor = UIColor.blue.cgColor
        bottomBorder.backgroundColor = UIColor.blue.cgColor
       backView.layer.addSublayer(topBorder)
       backView.layer.addSublayer(bottomBorder)
        backView.layer.addSublayer(leftBorder)
    }
    
    func setGradientBackground() {
        let colorTop = UIColor(red: 253.0/255.0, green: 164.0/255.0, blue: 40.0/255.0, alpha: 1.0).cgColor
        let colormiddle =  UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        
                    
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [colorTop,colormiddle]
        gradientLayer.locations = [0.0, 0.5]
        gradientLayer.frame = self.view.bounds
                
        self.view.layer.insertSublayer(gradientLayer, at:0)
    }
    
    


}


