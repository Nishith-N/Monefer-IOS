//
//  recipientsPageViewController.swift
//  monefer
//
//  Created by Anilkumar on 27/06/22.
//

import UIKit

class tablelist {
    var profIcon: String?
    var contactName: String?
    var messageLbl: String?
    var sendLbl: String?
    var currency: String?

    init(initprof:String, initcont:String, initmsg:String, inittime:String, initnicon:String) {
        self.profIcon = initprof
        self.contactName = initcont
        self.messageLbl = initmsg
        self.sendLbl = inittime
        self.currency = initnicon
    }
}

class recipientsPageViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
  
    var itemArray = [tablelist]()
    
    var recipName = ""
    var recipBank = ""
    var recipSend = ""

    @IBOutlet weak var recipientListTable: UITableView!
  
    @IBOutlet weak var searchImage: UIButton!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var recipientLabel: UILabel!
    @IBOutlet weak var headerView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tableviewcell1 = tablelist(initprof: "prof-1", initcont: "Swaroop", initmsg: "Eastern Bank LTD.", inittime: "SEND", initnicon: "INR")
        itemArray.append(tableviewcell1)
        let tableviewcell2 = tablelist(initprof: "prof-0", initcont: "Reece", initmsg: "City Bank LTD.", inittime: "SEND", initnicon: "USD")
        itemArray.append(tableviewcell2)
        let tableviewcell3 = tablelist(initprof: "prof-3", initcont: "Trent", initmsg: "Kotak Mahindra Bank", inittime: "SEND", initnicon: "EUR")
        itemArray.append(tableviewcell3)
       
        
        recipientListTable.register(recipientCustomTableViewCell.self, forCellReuseIdentifier: "Cell")
        
        headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0).isActive = true
        headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0).isActive = true
        headerView.heightAnchor.constraint(equalToConstant: 130).isActive = true
        headerView.translatesAutoresizingMaskIntoConstraints = false
        
        recipientLabel.topAnchor.constraint(equalTo: headerView.topAnchor, constant: 10).isActive = true
        recipientLabel.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 20).isActive = true
        recipientLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
        recipientLabel.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -20).isActive = true
        recipientLabel.translatesAutoresizingMaskIntoConstraints = false
        
        searchTextField.topAnchor.constraint(equalTo: recipientLabel.bottomAnchor, constant: 10).isActive = true
        searchTextField.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 20).isActive = true
        searchTextField.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.size.width-30).isActive = true
        searchTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        searchTextField.translatesAutoresizingMaskIntoConstraints = false
        
        searchImage.topAnchor.constraint(equalTo: recipientLabel.bottomAnchor, constant: 20).isActive = true
        searchImage.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -20).isActive = true
        searchImage.heightAnchor.constraint(equalToConstant: 30).isActive = true
        searchImage.widthAnchor.constraint(equalToConstant: 30).isActive = true
        searchImage.translatesAutoresizingMaskIntoConstraints = false
        
        searchTextField.layer.borderColor = UIColor.lightGray.cgColor
        searchTextField.layer.borderWidth = 1.0
        searchTextField.layer.cornerRadius = 10.0
        searchTextField.clipsToBounds = true
        
        
        recipientListTable.topAnchor.constraint(equalTo: headerView.bottomAnchor, constant: -20).isActive = true
        recipientListTable.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        recipientListTable.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0).isActive = true
        recipientListTable.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0).isActive = true
        recipientListTable.translatesAutoresizingMaskIntoConstraints = false
        
        recipientListTable.delegate = self
        recipientListTable.dataSource = self
        
        searchTextField.setLeftPaddingPoints(10)
        searchTextField.delegate = self
        
        
        
    
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == searchTextField
        {
            textField.becomeFirstResponder()
        }
    }
    
   
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == searchTextField
        {
            textField.resignFirstResponder()
        }
        return true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                    recipientCustomTableViewCell else {fatalError("Unable to run")}
            
            if indexPath.section == 0
            {
                cell.contacts.text = "Nishith"
                cell.profimage.image = UIImage(named: "prof-2")
                
            }
            if indexPath.section == 1
            {
                cell.contacts.text = itemArray[indexPath.row].contactName
                cell.profimage.image = UIImage(named: itemArray[indexPath.row].profIcon!)
            }
            
              cell.msge.text = itemArray[indexPath.row].messageLbl
             cell.sendLbl.text = itemArray[indexPath.row].sendLbl
              cell.notifilbl.text = itemArray[indexPath.row].currency
             
              
            
            return cell
        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        if indexPath.section == 0
        {
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "BankActivityViewController") as! BankActivityViewController
            self.navigationController?.pushViewController(vc, animated: true)
            recipSend = itemArray[indexPath.row].currency!
            if(recipSend == "INR")
            {
                vc.currentBalance = inrBalanace
            }
            else if(recipSend == "USD")
            {
                vc.currentBalance = usdBalanace
            }
            else if(recipSend == "EUR")
            {
                vc.currentBalance = eurBalance
            }
            vc.recieverSend = self.recipSend
            
        }
        
        if indexPath.section == 1
        {
        let vc = storyboard?.instantiateViewController(withIdentifier: "recipientInfoViewController") as! recipientInfoViewController
        recipName = itemArray[indexPath.row].contactName!
        recipBank = itemArray[indexPath.row].messageLbl!
        recipSend = itemArray[indexPath.row].currency!
        
        vc.recieverName = self.recipName
        vc.recieverBank = self.recipBank
        vc.recieverSend = self.recipSend
        self.navigationController?.pushViewController(vc, animated: true)
        }
    }
 
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        let myLabel = UILabel()
        myLabel.frame = CGRect(x: 20, y: 15, width: 320, height: 50)
        myLabel.font = UIFont.init(name: "Rockwell", size: 30)
        if section == 0
        {
        myLabel.text = "My Accounts"
        }
        else if section == 1
        {
            myLabel.text = "Other Accounts"
        }

        let headerView = UIView()
        headerView.addSubview(myLabel)
        
       

        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
}


