//
//  loginViewController.swift
//  monefer
//
//  Created by Anilkumar on 24/06/22.
//

import UIKit

class loginViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    let screenWidth = UIScreen.main.bounds.width
    override func viewDidLoad() {
        super.viewDidLoad()
        
        backgroundView.layer.cornerRadius = 30.0
        backgroundView.clipsToBounds = true
        
        loginButton.topAnchor.constraint(equalTo: backgroundView.topAnchor, constant: backgroundView.frame.height-50).isActive = true
        loginButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        loginButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        loginButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: (screenWidth/2)-50).isActive = true
       
        loginButton.translatesAutoresizingMaskIntoConstraints = false
        
        loginButton.backgroundColor = .black
        loginButton.layer.cornerRadius = loginButton.frame.width/2
        loginButton.clipsToBounds = true
        
        usernameTextField.layer.cornerRadius = 15.0
        usernameTextField.clipsToBounds = true
        
        passwordTextField.layer.cornerRadius = 15.0
        passwordTextField.clipsToBounds = true
        passwordTextField.isSecureTextEntry = true
        
        usernameTextField.delegate = self
        passwordTextField.delegate = self
        
        usernameTextField.setLeftPaddingPoints(10)
        passwordTextField.setLeftPaddingPoints(10)
        
        self.loginButton.addTarget(self, action: #selector(loginBtnAction(sender:)), for: .touchUpInside)
        // Do any additional setup after loading the view.
    }
    
    @objc func loginBtnAction(sender: UIButton)
    {
        if(usernameTextField.text == "nishith" && passwordTextField.text == "1234")
        {
        let vc = storyboard?.instantiateViewController(withIdentifier: "aboutViewController") as! aboutViewController
        self.navigationController?.pushViewController(vc, animated: true)
        }
        else
        {
            let alertController = UIAlertController(title: "Error", message:
                    "Invalid Credentials", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "Try Again", style: .default))

                self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == usernameTextField
        {
            textField.becomeFirstResponder()
        }
        if textField == passwordTextField
        {
            textField.becomeFirstResponder()
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == usernameTextField
        {
            passwordTextField.becomeFirstResponder()
        }
        if textField == passwordTextField
        {
            textField.resignFirstResponder()
        }
        return true
    }


}
