import UIKit

class usdBanklist {
    var profIcon: String?
    var contactName: String?
    var messageLbl: String?
    var sendLbl: String?
    var currency: String?

    init(initprof:String, initcont:String, initmsg:String, inittime:String, initnicon:String) {
        self.profIcon = initprof
        self.contactName = initcont
        self.messageLbl = initmsg
        self.sendLbl = inittime
        self.currency = initnicon
    }
}
class BankActivityViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var itemArray = [usdBanklist]()
    var currentBalance = 0.00
    
    @IBOutlet weak var convertMoneyLabel: UILabel!
    
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var usdTransTableView: UITableView!
    @IBOutlet weak var currencyBalanceLabel: UILabel!
    @IBOutlet weak var convertMoneyBtn: UIButton!
    @IBOutlet weak var convertView: UIView!
    var recieverSend = ""
    @IBOutlet weak var bankDetailsBtn: UIButton!
    @IBOutlet weak var headerCurrencyLabel: UILabel!
    @IBOutlet weak var headerAmountLabel: UILabel!
    @IBOutlet weak var HeaderView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let tableviewcell1 = usdBanklist(initprof: "prof-1", initcont: "Surja Sen Das Raj", initmsg: "Payment Recieved", inittime: "+333 " + recieverSend, initnicon: "Mar 10, 2022")
        itemArray.append(tableviewcell1)
        let tableviewcell2 = usdBanklist(initprof: "prof-2", initcont: "Reece", initmsg: "Payment Sent", inittime: "-70 " + recieverSend, initnicon: "Mar 2,2022")
        itemArray.append(tableviewcell2)
        let tableviewcell3 = usdBanklist(initprof: "prof-3", initcont: "Trent", initmsg: "Payment Sent", inittime: "-40 " + recieverSend, initnicon: "April 2,2022")
        itemArray.append(tableviewcell3)
        
        usdTransTableView.register(usdBankCustomTableViewCell.self, forCellReuseIdentifier: "Cell")
        
        HeaderView.layer.cornerRadius = 30.0
        HeaderView.clipsToBounds = true
        
        headerCurrencyLabel.text = recieverSend + " Balance Available"
        headerAmountLabel.text = "\(currentBalance)"
        
        if (recieverSend != "EUR")
        {
            convertMoneyBtn.isEnabled = false
            convertMoneyLabel.textColor = .lightGray
        }
        else
        {
            convertMoneyBtn.isEnabled = true
            convertMoneyLabel.textColor = .black
        }
        
        bankDetailsBtn.titleLabel?.font = .boldSystemFont(ofSize: 16)
        
        convertView.layer.shadowColor = UIColor.lightGray.cgColor
        convertView.layer.shadowOpacity = 10
        convertView.layer.shadowOffset = CGSize.zero
        convertView.layer.shadowRadius = 10
        
        homeBtn.layer.cornerRadius = homeBtn.frame.size.width/2
        homeBtn.clipsToBounds = true
        self.homeBtn.addTarget(self, action: #selector(homeBtnAction(sender:)), for: .touchUpInside)
        
        convertMoneyBtn.layer.cornerRadius = 8.0
        convertMoneyBtn.clipsToBounds = true
        self.convertMoneyBtn.addTarget(self, action: #selector(bankdetailsAction(sender:)), for: .touchUpInside)
        
        self.bankDetailsBtn.addTarget(self, action: #selector(seebankAction(sender:)), for: .touchUpInside)
        
        usdTransTableView.delegate = self
        usdTransTableView.dataSource = self
        
        convertView.layer.cornerRadius = 10.0
        
        currencyBalanceLabel.text = recieverSend + " Activity"
      print(currentBalance)
        if (currflag == 1)
        {
            headerAmountLabel.text = "\(currentBalance)"
        }
        
        


        // Do any additional setup after loading the view.
    }
    
    
    
    
    @objc func homeBtnAction(sender: UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "aboutViewController") as! aboutViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func seebankAction(sender:UIButton)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "myBankDetailsViewController") as! myBankDetailsViewController
                self.present(newViewController, animated: true, completion: nil)
    }
    
    @objc func bankdetailsAction(sender:UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "convertPageViewController") as! convertPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                usdBankCustomTableViewCell else {fatalError("Unable to run")}
        
        cell.profimage.image = UIImage(named: itemArray[indexPath.row].profIcon!)
          cell.contacts.text = itemArray[indexPath.row].contactName
          cell.msge.text = itemArray[indexPath.row].messageLbl
         cell.sendLbl.text = itemArray[indexPath.row].sendLbl
          cell.notifilbl.text = itemArray[indexPath.row].currency
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    

}
