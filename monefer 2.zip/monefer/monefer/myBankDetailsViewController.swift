//
//  myBankDetailsViewController.swift
//  monefer
//
//  Created by Anilkumar on 30/06/22.
//

import UIKit

class myBankDetailsViewController: UIViewController {

    @IBOutlet weak var addressLabel: UITextView!
    @IBOutlet weak var ibanLabel: UILabel!
    @IBOutlet weak var bicLabel: UILabel!
    @IBOutlet weak var headerBackView: UIView!
    @IBOutlet weak var insideOutsideToggle: UISegmentedControl!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var profImage: UIImageView!
    @IBOutlet weak var accountView: UIView!
    @IBOutlet weak var headerLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        headerLabel.text = "EUR Account\nDetails"
        
        accountView.layer.cornerRadius = 15.0
        accountView.clipsToBounds = true
        
        headerBackView.layer.cornerRadius = 15.0
        headerBackView.clipsToBounds = true
        profImage.layer.cornerRadius = profImage.frame.width/2
        profImage.clipsToBounds = true
        
        homeBtn.layer.cornerRadius = homeBtn.frame.width/2
        homeBtn.clipsToBounds = true

        // Do any additional setup after loading the view.
    }
    
    @IBAction func segmentControllerAction(_ sender: Any) {
        switch insideOutsideToggle.selectedSegmentIndex {
                   case 0:
                       bicLabel.text = "YUWXJDNU232"
                        ibanLabel.text = "HE34 7347 1012 2882"
       
                   case 1 :
                       bicLabel.text = "QasdasNU232"
                       ibanLabel.text = "HE82 7287 1083 2882"
       
                   default:
                       break
                   }
    }
    
//
            
            
        
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
